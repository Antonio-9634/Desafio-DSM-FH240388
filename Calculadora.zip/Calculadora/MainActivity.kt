package com.example.calculadorabasica

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.pow
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private lateinit var etNumero1: EditText
    private lateinit var etNumero2: EditText
    private lateinit var btnSumar: Button
    private lateinit var btnRestar: Button
    private lateinit var btnMultiplicar: Button
    private lateinit var btnDividir: Button
    private lateinit var btnPotencia: Button
    private lateinit var btnRaiz: Button
    private lateinit var tvResultado: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupButtonListeners()
    }

    private fun initViews() {
        etNumero1 = findViewById(R.id.etNumero1)
        etNumero2 = findViewById(R.id.etNumero2)
        btnSumar = findViewById(R.id.btnSumar)
        btnRestar = findViewById(R.id.btnRestar)
        btnMultiplicar = findViewById(R.id.btnMultiplicar)
        btnDividir = findViewById(R.id.btnDividir)
        btnPotencia = findViewById(R.id.btnPotencia)
        btnRaiz = findViewById(R.id.btnRaiz)
        tvResultado = findViewById(R.id.tvResultado)
    }

    private fun setupButtonListeners() {
        btnSumar.setOnClickListener { calcularOperacion("+") }
        btnRestar.setOnClickListener { calcularOperacion("-") }
        btnMultiplicar.setOnClickListener { calcularOperacion("*") }
        btnDividir.setOnClickListener { calcularOperacion("/") }
        btnPotencia.setOnClickListener { calcularOperacion("^") }
        btnRaiz.setOnClickListener { calcularOperacion("√") }
    }

    private fun calcularOperacion(operacion: String) {
        if (etNumero1.text.isEmpty()) {
            etNumero1.error = "Ingrese el primer número"
            return
        }

        val num1 = etNumero1.text.toString().toDouble()

        if (operacion != "√" && etNumero2.text.isEmpty()) {
            etNumero2.error = "Ingrese el segundo número"
            return
        }

        val num2 = if (operacion != "√") etNumero2.text.toString().toDouble() else 0.0

        try {
            val resultado = when (operacion) {
                "+" -> num1 + num2
                "-" -> num1 - num2
                "*" -> num1 * num2
                "/" -> {
                    if (num2 == 0.0) {
                        Toast.makeText(this, "No se puede dividir entre cero", Toast.LENGTH_SHORT).show()
                        return
                    }
                    num1 / num2
                }
                "^" -> num1.pow(num2)
                "√" -> sqrt(num1)
                else -> 0.0
            }

            mostrarResultado(num1, num2, resultado, operacion)
        } catch (e: Exception) {
            Toast.makeText(this, "Error en el cálculo: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun mostrarResultado(num1: Double, num2: Double, resultado: Double, operacion: String) {
        val simbolo = when (operacion) {
            "+" -> "+"
            "-" -> "-"
            "*" -> "×"
            "/" -> "÷"
            "^" -> "^"
            "√" -> "√"
            else -> ""
        }

        val operacionText = if (operacion == "√") {
            "√$num1"
        } else {
            "$num1 $simbolo $num2"
        }

        val resultadoFormateado = if (resultado % 1 == 0.0) {
            resultado.toInt().toString()
        } else {
            "%.4f".format(resultado)
        }

        tvResultado.text = "$operacionText = $resultadoFormateado"
    }
}