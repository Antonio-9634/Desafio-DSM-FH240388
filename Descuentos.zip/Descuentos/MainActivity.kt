package com.example.calculadorasalarial

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {

    private lateinit var etNombre: EditText
    private lateinit var etSalario: EditText
    private lateinit var btnCalcular: Button
    private lateinit var tvResultados: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupButton()
    }

    private fun initViews() {
        etNombre = findViewById(R.id.etNombre)
        etSalario = findViewById(R.id.etSalario)
        btnCalcular = findViewById(R.id.btnCalcular)
        tvResultados = findViewById(R.id.tvResultados)
    }

    private fun setupButton() {
        btnCalcular.setOnClickListener {
            calcularSalarioNeto()
        }
    }

    private fun calcularSalarioNeto() {
        if (etNombre.text.isEmpty() || etSalario.text.isEmpty()) {
            Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
            return
        }

        val salarioBruto = etSalario.text.toString().toDoubleOrNull()
        if (salarioBruto == null || salarioBruto <= 0) {
            etSalario.error = "Ingrese un salario válido"
            return
        }

        val nombre = etNombre.text.toString()
        val descuentos = calcularDescuentos(salarioBruto)
        val salarioNeto = salarioBruto - descuentos.totalDescuentos

        mostrarResultados(nombre, salarioBruto, descuentos, salarioNeto)
    }

    private fun calcularDescuentos(salarioBruto: Double): Descuentos {
        // AFP (7.25%)
        val afp = salarioBruto * 0.0725

        // ISSS (3%)
        val isss = salarioBruto * 0.03

        // Renta (según tabla de tramos)
        val renta = calcularRenta(salarioBruto)

        return Descuentos(afp, isss, renta)
    }

    private fun calcularRenta(salarioBruto: Double): Double {
        return when {
            salarioBruto <= 472.00 -> 0.0
            salarioBruto <= 895.24 -> ((salarioBruto - 472.00) * 0.10) + 17.67
            salarioBruto <= 2038.10 -> ((salarioBruto - 895.24) * 0.20) + 60.00
            else -> ((salarioBruto - 2038.10) * 0.30) + 288.57
        }
    }

    private fun mostrarResultados(nombre: String, salarioBruto: Double, descuentos: Descuentos, salarioNeto: Double) {
        val df = DecimalFormat("#.##")
        val resultado = """
            Empleado: <b>$nombre</b>
            
            <u>Salario Bruto:</u> $${df.format(salarioBruto)}
            
            <u>Descuentos:</u>
            - AFP (7.25%): $${df.format(descuentos.afp)}
            - ISSS (3%): $${df.format(descuentos.isss)}
            - Renta: $${df.format(descuentos.renta)}
            <b>Total descuentos: $${df.format(descuentos.totalDescuentos)}</b>
            
            <u>Salario Neto:</u> <b>$${df.format(salarioNeto)}</b>
        """.trimIndent()

        tvResultados.text = android.text.Html.fromHtml(resultado, android.text.Html.FROM_HTML_MODE_LEGACY)
    }

    private data class Descuentos(
        val afp: Double,
        val isss: Double,
        val renta: Double
    ) {
        val totalDescuentos: Double
            get() = afp + isss + renta
    }
}