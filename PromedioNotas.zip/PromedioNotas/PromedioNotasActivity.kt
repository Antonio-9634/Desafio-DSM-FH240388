package com.example.promedionotas

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.DecimalFormat

class PromedioNotasActivity : AppCompatActivity() {

    // Declaración de variables para las vistas
    private lateinit var etNombre: EditText
    private lateinit var etNota1: EditText
    private lateinit var etNota2: EditText
    private lateinit var etNota3: EditText
    private lateinit var etNota4: EditText
    private lateinit var etNota5: EditText
    private lateinit var btnCalcular: Button
    private lateinit var tvResultado: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_promedionotas)

        // Inicializar vistas
        initViews()

        // Configurar el listener del botón
        btnCalcular.setOnClickListener {
            calcularPromedio()
        }
    }

    private fun initViews() {
        etNombre = findViewById(R.id.etNombre)
        etNota1 = findViewById(R.id.etNota1)
        etNota2 = findViewById(R.id.etNota2)
        etNota3 = findViewById(R.id.etNota3)
        etNota4 = findViewById(R.id.etNota4)
        etNota5 = findViewById(R.id.etNota5)
        btnCalcular = findViewById(R.id.btnCalcular)
        tvResultado = findViewById(R.id.tvResultado)
    }

    private fun calcularPromedio() {
        // Validar campos vacíos
        if (validarCamposVacios()) {
            Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
            return
        }

        // Obtener y validar notas
        val notas = obtenerNotasValidas()
        if (notas == null) {
            return // Ya se mostró el error en obtenerNotasValidas()
        }

        // Calcular promedio ponderado
        val promedio = calcularPromedioPonderado(notas)

        // Mostrar resultado
        mostrarResultado(promedio)
    }

    private fun validarCamposVacios(): Boolean {
        return etNombre.text.isEmpty() ||
                etNota1.text.isEmpty() ||
                etNota2.text.isEmpty() ||
                etNota3.text.isEmpty() ||
                etNota4.text.isEmpty() ||
                etNota5.text.isEmpty()
    }

    private fun obtenerNotasValidas(): List<Float>? {
        val notas = listOf(
            etNota1.text.toString().toFloatOrNull(),
            etNota2.text.toString().toFloatOrNull(),
            etNota3.text.toString().toFloatOrNull(),
            etNota4.text.toString().toFloatOrNull(),
            etNota5.text.toString().toFloatOrNull()
        )

        // Validar que todas las notas sean números válidos entre 0 y 10
        for ((index, nota) in notas.withIndex()) {
            val editText = when (index) {
                0 -> etNota1
                1 -> etNota2
                2 -> etNota3
                3 -> etNota4
                else -> etNota5
            }

            if (nota == null) {
                editText.error = "Ingrese un número válido"
                return null
            }

            if (nota < 0 || nota > 10) {
                editText.error = "La nota debe estar entre 0 y 10"
                return null
            }
        }

        return notas.map { it!! }
    }

    private fun calcularPromedioPonderado(notas: List<Float>): Float {
        // Ponderaciones: 20%, 15%, 25%, 15%, 25%
        return (notas[0] * 0.20f) +
                (notas[1] * 0.15f) +
                (notas[2] * 0.25f) +
                (notas[3] * 0.15f) +
                (notas[4] * 0.25f)
    }

    private fun mostrarResultado(promedio: Float) {
        val df = DecimalFormat("#.##")
        val resultado = if (promedio >= 6.0f) "APROBADO" else "REPROBADO"
        val color = if (promedio >= 6.0f) "#4CAF50" else "#F44336"

        val resultadoText = """
            Estudiante: ${etNombre.text}
            Promedio: <b>${df.format(promedio)}</b>
            Estado: <font color='$color'><b>$resultado</b></font>
        """.trimIndent()

        tvResultado.text = android.text.Html.fromHtml(resultadoText, android.text.Html.FROM_HTML_MODE_LEGACY)
    }
}